package ca.ubc.cs.cpsc210.translink.auth;

public class TranslinkToken {
    public static final String TRANSLINK_API_KEY = "AUTdIc0W3SywrqGn6OID";
}
